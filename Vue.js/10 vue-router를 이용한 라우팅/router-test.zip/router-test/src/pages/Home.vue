<template>
  <div class="card card-body">
    <h2>Home</h2>
  </div>
</template>

<script>
export default {
  name: 'Home',
};
</script>
